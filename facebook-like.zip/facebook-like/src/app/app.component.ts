import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'facebook-like';


  createPost(title: HTMLInputElement, link: HTMLInputElement): boolean {
    console.log(title.value)
    console.log(link.value)

    return false;
  }
}
