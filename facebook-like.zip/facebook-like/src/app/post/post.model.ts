export class Post{ 
  title : String
  link : String
  like : number
  dislike: number


  constructor(title : String, link : String, like : number, dislike : number){
    this.title = title;
    this.link = link;
    this.like = like;
    this.dislike = dislike;
  }

  addLike() : void { // void is used if we doesn't want to return anything
    this.like = this.like +1
  }
  
  addDislike():void{
    this.dislike +=1
  }
  
}