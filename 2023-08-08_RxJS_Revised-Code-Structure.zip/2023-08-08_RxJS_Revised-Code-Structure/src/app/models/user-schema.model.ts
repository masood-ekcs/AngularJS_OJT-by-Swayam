export interface userSchema {
  id: Number;
  userInputLog: string;
  date: Date;
}
