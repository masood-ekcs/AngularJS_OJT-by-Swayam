export interface log{
    id: string,
    text: string,
    date: string
}